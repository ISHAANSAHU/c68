import React ,{Component} from 'react';
import {Text,View,TouchableOPacity,StyleSheet} from 'react-native';
import {createAppContainer} from 'react-navigation';
import facebook from './screens/facebook';
import instagram from './screens/instagram';
import {createBottomTabNavigator} from 'react-navigation-tabs'
export default class App extends Component {
  constructor(){
    super();
    this.state={

    }
  }
  render(){
    return <AppContainer/>
  }
}
const TabNavigator=createBottomTabNavigator({
 Facebook:{screen:facebook},
 Instagram:{screen:instagram},
})
const AppContainer =createAppContainer(TabNavigator)
