import React,{Component}from "react"
import {Text,View,TouchableOpacity} from "react-native";
export default class instagram extends Component{
  constructor(){
    super();
  }
  render(){
    return(
      <View><Text>Instagram</Text></View>
    )
  }
}