import React,{Component}from "react"
import {Text,View,TouchableOpacity} from "react-native";
export default class facebook extends Component{
  constructor(){
    super();
  }
  render(){
    return(
      <View><Text>Facebook</Text></View>
    )
  }
}